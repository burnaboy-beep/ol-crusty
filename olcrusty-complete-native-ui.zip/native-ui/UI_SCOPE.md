# UI scope and implementation notes

## Native routes included
- Farm dashboard with CLAW balance, six-hour session countdown, start action, Tide Boost, Squall, Driftbox, invite, rank, notices, and missions entry points
- Leaderboard with cycle explanation, podium, sample rows, and scoring details
- Wallet with current local balance, disabled deposit/withdraw actions, wallet-address entry point, and honest empty activity state
- Signup/email entry form with explicit notice that OTP is not sent
- Invite code and invite rewards, invited-friends empty/list states
- Activity history for session status (not fake wallet transactions)
- Notices list and notice detail
- Support, notifications, settings, profile, wallet address, missions, Driftbox, rank ladder, language, terms, account deletion, leaderboard details, Tide Boost, and Squall screens
- Shared native card, action row, buttons, labels, and navigation helpers

## Locked mechanics represented from the project handover
- Six-hour farming session
- Base reward of 25 CLAW for a completed session
- Tide Boost: three rewarded ads, all-or-nothing; 2.5x for the remainder of the session; one use per session
- Squall: three rewarded ads, all-or-nothing; one Driftbox token and no direct CLAW mint
- Driftbox card outcomes: Common 60% / 2.0x, Rare 30% / 2.25x, Legendary 10% / 2.5x
- Ranks: Hatchling 1.0x at 0; Deckhand 1.2x at 5; Reef Runner 1.4x at 15; Tide Master 1.7x at 30; Colony Elder 2.1x at 50
- Invite rewards are displayed as rules only, not issued from this UI

## Not production-connected
- Email OTP/authentication
- Rewarded ad SDK callbacks and server-side reward validation
- Supabase or other backend
- Live leaderboard and prize calculation
- Wallet address validation, USDT payout, or deposits/withdrawals
- Push notifications
- KYC, device fingerprinting, fraud controls, founder/admin dashboard
- Real notice and mission publishing
- Final legal text and any undecided leaderboard tie/carryover rules

## Before installing
The user project has reported uncommitted and backup files. Do not reset/clean Git. The install script creates a timestamped backup of the existing activity before replacing it.
