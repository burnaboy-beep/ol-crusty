# Ol' Crusty — Complete Native UI Package

This is a native Kotlin/Android Views implementation for the existing `com.omnexia.olcrusty` app. It is not a web app, WebView, Capacitor, or Jetpack Compose project.

## Upload and install
1. Upload this ZIP to the root of your GitHub repository using the GitHub web interface.
2. In Codespaces, extract it at the repository root:
   `unzip -o olcrusty-complete-native-ui.zip`
3. Run the installer from the repository root:
   `bash native-ui/install-native-ui.sh`
4. Build the APK:
   `./gradlew :app:assembleDebug --no-daemon`

The installer checks that it is in the Android project root and creates a timestamped backup of the current `MainActivity.kt` before replacing it. It does not delete unrelated files. Review `git diff -- app/src/main/java/com/omnexia/olcrusty/MainActivity.kt` before committing.

## Included
- `native-ui/app/src/main/java/com/omnexia/olcrusty/MainActivity.kt`
- `native-ui/install-native-ui.sh`
- `native-ui/UI_SCOPE.md`

## Important
The package includes a comprehensive native UI pass, but it is not a production backend. Authentication/OTP, real rewarded ads, wallet transactions, live leaderboard, push notifications, payout administration, and other server-backed behavior are explicitly marked as not connected. The local timer/balance is only a UI demonstration and is not a secure rewards ledger. Check the latest mechanics document and working-tree diff before replacing your current activity.
