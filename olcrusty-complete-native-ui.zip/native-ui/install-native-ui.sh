#!/usr/bin/env bash
set -euo pipefail

# Run from the root of the existing /workspaces/ol-crusty repository:
# bash native-ui/install-native-ui.sh
TARGET="app/src/main/java/com/omnexia/olcrusty/MainActivity.kt"
SOURCE="native-ui/app/src/main/java/com/omnexia/olcrusty/MainActivity.kt"
STAMP="$(date +%Y%m%d-%H%M%S)"

if [[ ! -f "settings.gradle.kts" || ! -f "app/build.gradle.kts" ]]; then
  echo "ERROR: Run this command from the root of the existing Ol' Crusty Android project."
  exit 2
fi

if [[ ! -f "$SOURCE" ]]; then
  echo "ERROR: Missing package source: $SOURCE"
  echo "Make sure the ZIP was extracted at the repository root and the native-ui folder exists."
  exit 3
fi

mkdir -p "$(dirname "$TARGET")"
if [[ -f "$TARGET" ]]; then
  cp -p "$TARGET" "$TARGET.before-native-ui-$STAMP"
  echo "Backup created: $TARGET.before-native-ui-$STAMP"
fi

cp "$SOURCE" "$TARGET"
echo "Installed native UI activity."
echo "Now build with: ./gradlew :app:assembleDebug --no-daemon"
