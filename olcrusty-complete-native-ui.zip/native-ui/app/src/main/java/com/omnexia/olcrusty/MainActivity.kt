package com.omnexia.olcrusty

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

/**
 * Ol' Crusty native UI implementation.
 *
 * This is a native Android Views activity. It contains local/demo UI state only;
 * production authentication, rewarded ads, wallet transactions, backend rewards,
 * leaderboard sync, and payouts must be connected to trusted services separately.
 */
class MainActivity : Activity() {
    private val ocean = Color.rgb(7, 19, 31)
    private val panel = Color.rgb(15, 32, 47)
    private val panel2 = Color.rgb(21, 43, 59)
    private val gold = Color.rgb(245, 190, 75)
    private val cream = Color.rgb(244, 239, 224)
    private val muted = Color.rgb(151, 171, 184)
    private val coral = Color.rgb(255, 119, 104)
    private val seafoam = Color.rgb(91, 218, 185)
    private val blue = Color.rgb(75, 171, 230)

    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomNav: LinearLayout
    private var currentRoute = "farm"
    private var balance = 0.0
    private var sessionStart = 0L
    private var sessionEnd = 0L
    private var farming = false
    private var tideBoostUsed = false
    private var driftboxes = 0
    private var inviteCount = 0
    private var countdown: CountDownTimer? = null
    private var countdownLabel: TextView? = null
    private var balanceLabel: TextView? = null
    private val prefs by lazy { getSharedPreferences("ol_crusty_local_ui", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ocean
        window.navigationBarColor = ocean
        window.decorView.systemUiVisibility = 0
        loadLocalState()
        render("farm")
    }

    override fun onPause() {
        super.onPause()
        saveLocalState()
    }

    override fun onDestroy() {
        countdown?.cancel()
        super.onDestroy()
    }

    private fun loadLocalState() {
        balance = prefs.getFloat("balance", 0f).toDouble()
        sessionStart = prefs.getLong("sessionStart", 0L)
        sessionEnd = prefs.getLong("sessionEnd", 0L)
        farming = prefs.getBoolean("farming", false) && sessionEnd > System.currentTimeMillis()
        tideBoostUsed = prefs.getBoolean("tideBoostUsed", false)
        driftboxes = prefs.getInt("driftboxes", 0)
        inviteCount = prefs.getInt("inviteCount", 0)
        if (farming && sessionEnd <= System.currentTimeMillis()) finishSession()
    }

    private fun saveLocalState() {
        prefs.edit()
            .putFloat("balance", balance.toFloat())
            .putLong("sessionStart", sessionStart)
            .putLong("sessionEnd", sessionEnd)
            .putBoolean("farming", farming)
            .putBoolean("tideBoostUsed", tideBoostUsed)
            .putInt("driftboxes", driftboxes)
            .putInt("inviteCount", inviteCount)
            .apply()
    }

    private fun render(route: String) {
        currentRoute = route
        countdown?.cancel()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ocean)
        }
        setContentView(root)
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(10))
        }
        if (route in listOf("farm", "leaderboard", "wallet")) {
            addBrand(topBar)
            val spacer = View(this)
            topBar.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
            topBar.addView(pill("● LIVE", seafoam, panel2))
            topBar.addView(space(8))
            topBar.addView(circleButton("⚙", muted) { render("settings") })
        } else {
            topBar.addView(text("‹", 30, gold).apply {
                setPadding(0, 0, dp(14), 0)
                setOnClickListener { render(parentRoute(route)) }
            })
            topBar.addView(text(routeTitle(route), 19, cream, true), LinearLayout.LayoutParams(0, -2, 1f))
            topBar.addView(text("●", 16, seafoam).apply {
                setOnClickListener { render("notifications") }
            })
        }
        root.addView(topBar)
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(0, 0, 0, dp(18))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), dp(20))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (route in listOf("farm", "leaderboard", "wallet")) {
            addBottomNav(route)
        }
        when (route) {
            "farm" -> farmScreen()
            "leaderboard" -> leaderboardScreen()
            "wallet" -> walletScreen()
            "signup" -> signupScreen()
            "invite" -> inviteScreen()
            "friends" -> friendsScreen()
            "history" -> historyScreen()
            "notices" -> noticesScreen()
            "notice-detail" -> noticeDetailScreen()
            "support" -> supportScreen()
            "notifications" -> notificationsScreen()
            "settings" -> settingsScreen()
            "profile" -> profileScreen()
            "wallet-address" -> walletAddressScreen()
            "missions" -> missionsScreen()
            "driftbox" -> driftboxScreen()
            "rank" -> rankScreen()
            "language" -> languageScreen()
            "terms" -> termsScreen()
            "delete-account" -> deleteAccountScreen()
            "leaderboard-detail" -> leaderboardDetailScreen()
            "tide-boost" -> boosterScreen("Tide Boost")
            "squall" -> boosterScreen("Squall")
            else -> farmScreen()
        }
        saveLocalState()
    }

    private fun parentRoute(route: String): String = when (route) {
        "notice-detail" -> "notices"
        "leaderboard-detail" -> "leaderboard"
        "wallet-address" -> "wallet"
        "tide-boost", "squall", "driftbox", "rank" -> "farm"
        "profile", "language", "terms", "delete-account", "support", "notifications" -> "settings"
        else -> "farm"
    }

    private fun routeTitle(route: String) = when (route) {
        "signup" -> "Create your account"
        "invite" -> "Invite crew"
        "friends" -> "Invited friends"
        "history" -> "Activity history"
        "notices" -> "Notices"
        "notice-detail" -> "Notice"
        "support" -> "Help & support"
        "notifications" -> "Notifications"
        "settings" -> "Settings"
        "profile" -> "My profile"
        "wallet-address" -> "Wallet address"
        "missions" -> "Missions"
        "driftbox" -> "Driftbox"
        "rank" -> "Your rank"
        "language" -> "Language"
        "terms" -> "Terms & policies"
        "delete-account" -> "Delete account"
        "leaderboard-detail" -> "Leaderboard details"
        "tide-boost" -> "Tide Boost"
        "squall" -> "Squall"
        else -> "Ol' Crusty"
    }

    private fun addBrand(target: LinearLayout) {
        val mark = text("OC", 14, ocean, true).apply {
            gravity = Gravity.CENTER
            background = rounded(gold, 13)
        }
        target.addView(mark, LinearLayout.LayoutParams(dp(38), dp(38)))
        target.addView(space(10))
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(text("OL' CRUSTY", 15, cream, true))
        labels.addView(text("OMNEXIA NETWORK", 9, muted, true))
        target.addView(labels)
    }

    private fun addBottomNav(selected: String) {
        bottomNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(10, 24, 37))
            setPadding(dp(8), dp(8), dp(8), dp(7))
        }
        val items = listOf(Triple("⌂", "Farm", "farm"), Triple("♜", "Ranks", "leaderboard"), Triple("◈", "Wallet", "wallet"), Triple("☷", "More", "settings"))
        items.forEach { (icon, label, route) ->
            val active = selected == route || (selected == "leaderboard" && route == "leaderboard")
            val col = if (active) gold else muted
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(3), 0, dp(2))
                setOnClickListener { render(route) }
            }
            item.addView(text(icon, 21, col, true).apply { gravity = Gravity.CENTER })
            item.addView(text(label, 10, col, active).apply { gravity = Gravity.CENTER })
            bottomNav.addView(item, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(bottomNav)
    }

    private fun farmScreen() {
        content.addView(text("AHOY, CAPTAIN  👋", 11, seafoam, true))
        gap(7)
        content.addView(text("Your ocean. Your haul.", 25, cream, true))
        content.addView(text("A little farming goes a long way.", 13, muted))
        gap(18)

        val hero = card().apply {
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(24, 65, 78), Color.rgb(14, 36, 51), Color.rgb(12, 27, 41))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), Color.rgb(49, 90, 99)) }
        }
        hero.addView(text("TOTAL CLAW BALANCE", 10, muted, true))
        gapIn(hero, 8)
        balanceLabel = text(fmt(balance), 34, gold, true)
        hero.addView(balanceLabel)
        hero.addView(text("CLAW  ·  In-app points", 12, seafoam))
        gapIn(hero, 18)
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        line.addView(text("🦀", 34, cream))
        line.addView(space(12))
        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        summary.addView(text(if (farming) "Farming in progress" else "Ready to set sail?", 15, cream, true))
        summary.addView(text(if (farming) "Your current session is underway." else "Start a 6-hour farming session.", 12, muted))
        line.addView(summary, LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(line)
        gapIn(hero, 15)
        countdownLabel = text(if (farming) "TIME LEFT  ${remaining()}" else "SESSION LENGTH  06:00:00", 13, cream, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(13), dp(12), dp(13))
            background = rounded(Color.rgb(9, 24, 36), 12)
        }
        hero.addView(countdownLabel)
        gapIn(hero, 13)
        hero.addView(primaryButton(if (farming) "FARMING ACTIVE" else "START FARMING  →") {
            if (farming) toast("Your session is already running.") else startFarming()
        }, LinearLayout.LayoutParams(-1, dp(50)))
        if (farming) startCountdown()
        content.addView(hero)

        gap(17)
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(statCard("⏱", "6 HOURS", "per session", gold), LinearLayout.LayoutParams(0, dp(92), 1f))
        stats.addView(space(10))
        stats.addView(statCard("⚓", "25 CLAW", "base haul", seafoam), LinearLayout.LayoutParams(0, dp(92), 1f))
        content.addView(stats)
        gap(21)
        section("BOOST YOUR HAUL", "Use your session wisely")
        gap(10)
        actionRow("🌊", "Tide Boost", "2.5× for this session", "OPEN", gold) { render("tide-boost") }
        gap(9)
        actionRow("🌪", "Squall", "Earn a Driftbox token", "OPEN", coral) { render("squall") }
        gap(9)
        actionRow("📦", "Driftbox", "$driftboxes token${if (driftboxes == 1) "" else "s"} available", "VIEW", seafoam) { render("driftbox") }
        gap(21)
        section("YOUR CREW", "Grow your invite network")
        gap(10)
        actionRow("🦀", "Invite friends", "$inviteCount completed invites", "INVITE", gold) { render("invite") }
        gap(9)
        actionRow("🏅", "Your rank", currentRank(), "VIEW", seafoam) { render("rank") }
        gap(21)
        section("STAY IN THE LOOP", "The latest from the crew")
        gap(10)
        actionRow("📣", "Notices", "News and announcements", "READ", blue) { render("notices") }
        gap(9)
        actionRow("🎯", "Missions", "Check available missions", "VIEW", coral) { render("missions") }
        gap(10)
        disclaimer()
    }

    private fun leaderboardScreen() {
        content.addView(text("THE CREW COMPETITION", 10, seafoam, true))
        gap(6)
        content.addView(text("Leaderboard", 28, cream, true))
        content.addView(text("Every two weeks, the most active crews rise.", 13, muted))
        gap(17)
        val cycle = card().apply { setPadding(dp(16), dp(15), dp(16), dp(15)) }
        cycle.addView(text("CURRENT CYCLE", 10, muted, true))
        gapIn(cycle, 5)
        cycle.addView(text("Two-week ocean run", 18, cream, true))
        cycle.addView(text("Prizes are reviewed before payout. $75 minimum threshold.", 12, muted))
        content.addView(cycle)
        gap(14)
        val podium = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        podium.addView(podiumCard("🥈", "Deckhand_7", "8,420", 94), LinearLayout.LayoutParams(0, dp(145), 1f))
        podium.addView(space(7))
        podium.addView(podiumCard("👑", "CaptainWave", "12,890", 118), LinearLayout.LayoutParams(0, dp(169), 1f))
        podium.addView(space(7))
        podium.addView(podiumCard("🥉", "ReefRunner", "7,960", 84), LinearLayout.LayoutParams(0, dp(135), 1f))
        content.addView(podium)
        gap(18)
        section("TOP SAILORS", "Demo preview · live data not connected")
        gap(8)
        val rows = listOf(
            Triple("01", "CaptainWave", "12,890 pts"),
            Triple("02", "Deckhand_7", "8,420 pts"),
            Triple("03", "ReefRunner", "7,960 pts"),
            Triple("04", "CoralQueen", "6,115 pts"),
            Triple("05", "TideChaser", "4,880 pts")
        )
        rows.forEachIndexed { i, row ->
            val box = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12)) }
            box.addView(text(row.first, 13, if (i == 0) gold else muted, true), LinearLayout.LayoutParams(dp(28), -2))
            box.addView(avatar(row.second.take(1), if (i % 2 == 0) coral else blue, 38))
            box.addView(space(10))
            val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            names.addView(text(row.second, 13, cream, true))
            names.addView(text(if (i == 0) "Colony Elder" else "Reef Runner", 10, muted))
            box.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(text(row.third, 12, gold, true))
            box.setOnClickListener { render("leaderboard-detail") }
            content.addView(box)
            gap(7)
        }
        gap(8)
        content.addView(secondaryButton("HOW SCORING WORKS") { render("leaderboard-detail") })
        gap(10)
        disclaimer()
    }

    private fun walletScreen() {
        content.addView(text("YOUR TREASURE CHEST", 10, seafoam, true))
        gap(6)
        content.addView(text("Wallet", 28, cream, true))
        content.addView(text("Your personal CLAW balance and payout history.", 13, muted))
        gap(17)
        val hero = card().apply {
            setPadding(dp(18), dp(20), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(53, 57, 48), Color.rgb(24, 42, 48), Color.rgb(13, 29, 42))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), Color.rgb(115, 104, 67)) }
        }
        hero.addView(text("AVAILABLE BALANCE", 10, muted, true))
        gapIn(hero, 7)
        hero.addView(text(fmt(balance), 33, gold, true))
        hero.addView(text("CLAW", 13, seafoam, true))
        gapIn(hero, 14)
        hero.addView(text("Deposit and withdrawal will unlock at launch.", 12, muted))
        content.addView(hero)
        gap(14)
        val disabled = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        disabled.addView(disabledAction("↓", "Deposit"), LinearLayout.LayoutParams(0, dp(77), 1f))
        disabled.addView(space(10))
        disabled.addView(disabledAction("↑", "Withdraw"), LinearLayout.LayoutParams(0, dp(77), 1f))
        content.addView(disabled)
        gap(20)
        section("RECENT ACTIVITY", "Only real transactions belong here")
        gap(8)
        val empty = card().apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(25), dp(20), dp(25)) }
        empty.addView(text("◷", 28, muted))
        gapIn(empty, 8)
        empty.addView(text("No wallet transactions yet", 15, cream, true))
        empty.addView(text("Farming sessions are not wallet transactions.", 12, muted).apply { gravity = Gravity.CENTER })
        content.addView(empty)
        gap(16)
        actionRow("▣", "Wallet address", "Manage your address when available", "VIEW", blue) { render("wallet-address") }
        gap(9)
        actionRow("↗", "Activity history", "View your local session history", "OPEN", seafoam) { render("history") }
        gap(14)
        disclaimer()
    }

    private fun signupScreen() {
        content.addView(text("WELCOME ABOARD", 10, seafoam, true))
        gap(8)
        content.addView(text("Join the crew.", 29, cream, true))
        content.addView(text("Create an account to keep your ocean journey together.", 13, muted))
        gap(20)
        val form = card().apply { setPadding(dp(16), dp(18), dp(16), dp(18)) }
        form.addView(text("Email address", 12, cream, true))
        gapIn(form, 7)
        val email = input("you@example.com", false)
        form.addView(email, LinearLayout.LayoutParams(-1, dp(50)))
        gapIn(form, 15)
        form.addView(text("Invitation code (optional)", 12, cream, true))
        gapIn(form, 7)
        val referral = input("Enter code", false)
        form.addView(referral, LinearLayout.LayoutParams(-1, dp(50)))
        gapIn(form, 18)
        form.addView(primaryButton("SEND EMAIL CODE") {
            if (email.text.toString().contains("@") && email.text.toString().contains(".")) {
                AlertDialog.Builder(this).setTitle("Email verification").setMessage("The real email OTP service is not connected yet. No code has been sent.").setPositiveButton("OK", null).show()
            } else toast("Enter a valid email address.")
        }, LinearLayout.LayoutParams(-1, dp(49)))
        content.addView(form)
        gap(12)
        content.addView(text("Email OTP and account creation require a backend connection before launch.", 11, muted))
    }

    private fun inviteScreen() {
        content.addView(text("BUILD YOUR CREW", 10, seafoam, true))
        gap(6)
        content.addView(text("Good crews grow together.", 25, cream, true))
        content.addView(text("Invite friends and climb the ranks as your network grows.", 13, muted))
        gap(18)
        val card = card().apply { setPadding(dp(18), dp(18), dp(18), dp(18)) }
        card.addView(text("YOUR INVITE CODE", 10, muted, true))
        gapIn(card, 7)
        val code = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        code.addView(text("OLCRUSTY92", 23, gold, true), LinearLayout.LayoutParams(0, -2, 1f))
        code.addView(circleButton("▢", gold) { copy("OLCRUSTY92") })
        card.addView(code)
        gapIn(card, 13)
        card.addView(primaryButton("COPY INVITE CODE") { copy("OLCRUSTY92") }, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(card)
        gap(15)
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(statCard("👥", inviteCount.toString(), "completed invites", gold), LinearLayout.LayoutParams(0, dp(90), 1f))
        stats.addView(space(10))
        stats.addView(statCard("🏅", currentRank(), "current rank", seafoam), LinearLayout.LayoutParams(0, dp(90), 1f))
        content.addView(stats)
        gap(20)
        section("INVITE REWARDS", "Locked rules")
        gap(9)
        infoRow("First completed invite", "+100 CLAW", gold)
        infoRow("Each later completed invite", "+50 CLAW", seafoam)
        gap(10)
        content.addView(secondaryButton("VIEW INVITED FRIENDS") { render("friends") })
        gap(10)
        content.addView(text("Referral rewards are shown as rules only here. This demo screen does not issue rewards or validate invite completion.", 11, muted))
    }

    private fun friendsScreen() {
        content.addView(text("YOUR NETWORK", 10, seafoam, true))
        gap(6)
        content.addView(text("Invited friends", 25, cream, true))
        content.addView(text("Your crew grows one completed invite at a time.", 13, muted))
        gap(18)
        if (inviteCount == 0) {
            emptyState("👥", "Your crew is just getting started", "Share your invite code to bring friends aboard.", "INVITE FRIENDS") { render("invite") }
        } else {
            repeat(inviteCount.coerceAtMost(20)) { i ->
                val row = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12)) }
                row.addView(avatar("C", seafoam, 40)); row.addView(space(11))
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                col.addView(text("Crew member ${i + 1}", 14, cream, true))
                col.addView(text("Invite status needs server verification", 11, muted))
                row.addView(col)
                content.addView(row); gap(8)
            }
        }
    }

    private fun historyScreen() {
        content.addView(text("YOUR LOGBOOK", 10, seafoam, true))
        gap(6)
        content.addView(text("Activity history", 25, cream, true))
        content.addView(text("Local farming session status only. This is not wallet transaction history.", 12, muted))
        gap(17)
        if (sessionStart == 0L) {
            emptyState("◷", "Nothing in the logbook yet", "Start your first six-hour farming session to begin.", "GO TO FARM") { render("farm") }
        } else {
            val box = card().apply { setPadding(dp(15), dp(15), dp(15), dp(15)) }
            box.addView(text(if (farming) "Farming session · In progress" else "Last farming session", 14, cream, true))
            gapIn(box, 6)
            box.addView(text(SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.getDefault()).format(Date(sessionStart)), 12, muted))
            gapIn(box, 8)
            box.addView(text(if (farming) "Time remaining: ${remaining()}" else "Session ended or is not active.", 12, seafoam))
            content.addView(box)
        }
    }

    private fun noticesScreen() {
        content.addView(text("FROM THE CAPTAIN'S DESK", 10, seafoam, true))
        gap(6)
        content.addView(text("Notices", 25, cream, true))
        content.addView(text("Announcements and updates from the Ol' Crusty crew.", 13, muted))
        gap(17)
        noticeCard("Welcome aboard, sailor!", "Welcome to Ol' Crusty. Your journey for CLAW starts here.", "Pinned notice", gold)
        gap(9)
        noticeCard("Wallet launch update", "Deposits and withdrawals remain disabled until launch/TGE.", "Product update", blue)
        gap(9)
        noticeCard("Keep your account safe", "Never share verification codes or wallet recovery phrases.", "Safety", coral)
        gap(12)
        content.addView(text("These are interface placeholders, not live announcements. Notices are intended to be posted manually by the team.", 11, muted))
    }

    private fun noticeDetailScreen() {
        content.addView(pill("PINNED NOTICE", gold, panel2))
        gap(12)
        content.addView(text("Welcome aboard, sailor!", 25, cream, true))
        gap(8)
        content.addView(text("Welcome to Ol' Crusty. Your journey for CLAW starts here.", 15, muted))
        gap(18)
        content.addView(text("Start with a six-hour farming session, explore your boosters, and invite friends to build your crew. The points shown in the app are in-app CLAW points, not a launched tradable token.", 14, cream))
        gap(20)
        content.addView(secondaryButton("BACK TO NOTICES") { render("notices") })
    }

    private fun supportScreen() {
        content.addView(text("WE'RE HERE TO HELP", 10, seafoam, true))
        gap(6)
        content.addView(text("Help & support", 25, cream, true))
        content.addView(text("Find answers or prepare a message for the team.", 13, muted))
        gap(17)
        actionRow("❔", "Farming questions", "Sessions last six hours", "READ", gold) { infoDialog("Farming", "A session lasts six hours. The base reward is 25 CLAW per completed session.") }
        gap(9)
        actionRow("◈", "Wallet & launch", "Wallet features are not active yet", "READ", blue) { infoDialog("Wallet", "Deposit and withdrawal are disabled until launch/TGE.") }
        gap(9)
        actionRow("🛟", "Contact support", "Email integration not connected", "OPEN", coral) { infoDialog("Support", "A real support channel has not been configured in this UI package.") }
    }

    private fun notificationsScreen() {
        content.addView(text("YOUR UPDATES", 10, seafoam, true))
        gap(6)
        content.addView(text("Notifications", 25, cream, true))
        content.addView(text("Important updates will appear here when notifications are connected.", 13, muted))
        gap(18)
        emptyState("🔔", "You're all caught up", "There are no live notifications in this prototype.", "VIEW NOTICES") { render("notices") }
    }

    private fun settingsScreen() {
        content.addView(text("MAKE IT YOURS", 10, seafoam, true))
        gap(6)
        content.addView(text("Settings", 26, cream, true))
        content.addView(text("Manage your profile and app preferences.", 13, muted))
        gap(18)
        actionRow("👤", "My profile", "Nickname and invitation details", "OPEN", gold) { render("profile") }
        gap(9)
        actionRow("🔔", "Notifications", "Your app updates", "OPEN", blue) { render("notifications") }
        gap(9)
        actionRow("文", "Language", "English", "OPEN", seafoam) { render("language") }
        gap(9)
        actionRow("▤", "Terms & policies", "Read app policies", "OPEN", muted) { render("terms") }
        gap(9)
        actionRow("❔", "Help & support", "Get help", "OPEN", coral) { render("support") }
        gap(18)
        val version = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        version.addView(text("App version", 13, cream), LinearLayout.LayoutParams(0, -2, 1f))
        version.addView(text("2.0.18 · UI preview", 12, muted))
        content.addView(version)
        gap(15)
        content.addView(secondaryButton("LOG OUT") { infoDialog("Log out", "Account sessions are not connected in this UI preview.") })
        gap(8)
        content.addView(text("Delete account", 12, coral).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)); setOnClickListener { render("delete-account") } })
    }

    private fun profileScreen() {
        val avatarWrap = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }
        avatarWrap.addView(avatar("O", coral, 82))
        content.addView(avatarWrap)
        gap(8)
        content.addView(text("Ol' Crusty Captain", 20, cream, true).apply { gravity = Gravity.CENTER })
        content.addView(text("Local profile preview", 12, muted).apply { gravity = Gravity.CENTER })
        gap(22)
        section("PROFILE DETAILS", "Edit actions are local previews")
        gap(9)
        infoRow("Nickname", "Ol' Crusty", cream)
        infoRow("Invitation code", "OLCRUSTY92", gold)
        infoRow("Email", "Not connected", muted)
        gap(12)
        content.addView(secondaryButton("COPY INVITATION CODE") { copy("OLCRUSTY92") })
        gap(10)
        content.addView(text("Profile editing and verified account details require authentication to be connected.", 11, muted))
    }

    private fun walletAddressScreen() {
        content.addView(text("WALLET SETUP", 10, seafoam, true))
        gap(6)
        content.addView(text("Wallet address", 25, cream, true))
        content.addView(text("Address management is reserved for the launch stage.", 13, muted))
        gap(18)
        val box = card().apply { setPadding(dp(16), dp(17), dp(16), dp(17)) }
        box.addView(text("USDT wallet address", 12, cream, true))
        gapIn(box, 7)
        box.addView(input("No address connected", false).apply { isEnabled = false }, LinearLayout.LayoutParams(-1, dp(50)))
        gapIn(box, 12)
        box.addView(text("Do not paste private keys or recovery phrases into this app.", 11, coral))
        content.addView(box)
        gap(12)
        content.addView(text("Saving an address and making payouts are not implemented in this UI package.", 11, muted))
    }

    private fun missionsScreen() {
        content.addView(text("SIDE QUESTS", 10, seafoam, true))
        gap(6)
        content.addView(text("Missions", 25, cream, true))
        content.addView(text("Check tasks from the crew. Mission publishing is not connected yet.", 13, muted))
        gap(17)
        missionCard("Follow the crew", "Stay updated on official announcements.", "Coming soon", gold)
        gap(9)
        missionCard("Bring a friend aboard", "Invite a friend to join your crew.", "Referral rules apply", seafoam)
        gap(9)
        missionCard("Check the notices", "Read the latest crew updates.", "Available", blue) { render("notices") }
        gap(14)
        content.addView(text("Missions may be managed by the founder once the backend/admin tools are connected.", 11, muted))
    }

    private fun driftboxScreen() {
        content.addView(text("A MYSTERY FROM THE DEEP", 10, seafoam, true))
        gap(6)
        content.addView(text("Driftbox", 27, cream, true))
        content.addView(text("Open a box token to reveal a haul card.", 13, muted))
        gap(18)
        val art = card().apply {
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(25), dp(20), dp(25))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(55, 51, 39), Color.rgb(20, 44, 54))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), Color.rgb(135, 111, 60)) }
        }
        art.addView(text("📦", 66, gold))
        gapIn(art, 8)
        art.addView(text("$driftboxes BOX TOKEN${if (driftboxes == 1) "" else "S"}", 12, gold, true))
        art.addView(text("Mystery haul awaits", 16, cream, true))
        gapIn(art, 16)
        art.addView(primaryButton("OPEN A DRIFTBOX") {
            if (driftboxes <= 0) toast("You need a Driftbox token. Squall is the token route.")
            else {
                driftboxes--
                val roll = (1..100).random()
                val (name, weight) = when {
                    roll <= 60 -> "Common Haul" to "2.0×"
                    roll <= 90 -> "Rare Haul" to "2.25×"
                    else -> "Legendary Haul" to "2.5×"
                }
                saveLocalState()
                AlertDialog.Builder(this).setTitle("Driftbox revealed!").setMessage("$name\nLeaderboard card weight: $weight\n\nThis is a local UI simulation. It does not mint CLAW or submit leaderboard scores.").setPositiveButton("NICE", null).show()
                render("driftbox")
            }
        }, LinearLayout.LayoutParams(-1, dp(49)))
        content.addView(art)
        gap(15)
        section("POSSIBLE HAULS", "Card weights from the project rules")
        gap(8)
        infoRow("Common Haul · 60%", "2.0× weight", cream)
        infoRow("Rare Haul · 30%", "2.25× weight", seafoam)
        infoRow("Legendary Haul · 10%", "2.5× weight", gold)
        gap(10)
        content.addView(text("This screen simulates reveal animation/outcomes locally. Production ownership and scoring need a trusted backend.", 11, muted))
    }

    private fun rankScreen() {
        content.addView(text("CLIMB THE TIDE", 10, seafoam, true))
        gap(6)
        content.addView(text("Your rank", 26, cream, true))
        content.addView(text("Rank multipliers are defined by completed invites.", 13, muted))
        gap(18)
        val ranks = listOf(
            Triple("Hatchling", "0 invites", "1.0×"),
            Triple("Deckhand", "5 invites", "1.2×"),
            Triple("Reef Runner", "15 invites", "1.4×"),
            Triple("Tide Master", "30 invites", "1.7×"),
            Triple("Colony Elder", "50 invites", "2.1×")
        )
        ranks.forEachIndexed { i, r ->
            val row = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)) }
            row.addView(text(listOf("🐣", "⚓", "🌊", "🦈", "👑")[i], 24, gold))
            row.addView(space(11))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(text(r.first, 14, cream, true))
            col.addView(text(r.second, 11, muted))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(pill(r.third, gold, panel2))
            if (r.first == currentRank()) row.background = roundedStroke(panel2, gold, 15)
            content.addView(row); gap(8)
        }
        gap(8)
        content.addView(text("Current local invite count: $inviteCount. Only verified server invites should determine a production rank.", 11, muted))
    }

    private fun languageScreen() {
        content.addView(text("LANGUAGE SETTINGS", 10, seafoam, true))
        gap(6)
        content.addView(text("Choose your language", 24, cream, true))
        gap(18)
        actionRow("✓", "English", "Current language", "SELECTED", seafoam) { toast("English is already selected.") }
        gap(9)
        actionRow("文", "More languages", "Additional translations not available", "SOON", muted) { toast("More languages are not available yet.") }
    }

    private fun termsScreen() {
        content.addView(text("LEGAL & TRANSPARENCY", 10, seafoam, true))
        gap(6)
        content.addView(text("Terms & policies", 24, cream, true))
        gap(14)
        infoBlock("CLAW points", "CLAW is currently an in-app points system. It is not a launched tradable token.")
        infoBlock("Wallet availability", "Deposit and withdrawal remain disabled until launch/TGE.")
        infoBlock("Rewards and eligibility", "Rewards, invites, leaderboard scores, and payouts require verified server-side logic before production.")
        infoBlock("Privacy and security", "Do not share passwords, one-time codes, private keys, or recovery phrases.")
        gap(10)
        content.addView(text("These short notes are informational UI placeholders, not the final legal terms. Publish approved policies before launch.", 11, muted))
    }

    private fun deleteAccountScreen() {
        content.addView(text("ACCOUNT CONTROL", 10, coral, true))
        gap(6)
        content.addView(text("Delete account", 25, cream, true))
        content.addView(text("Account deletion requires a verified account and a secure backend flow.", 13, muted))
        gap(18)
        val box = card().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        box.addView(text("Before you continue", 15, cream, true))
        gapIn(box, 8)
        box.addView(text("This UI preview is not connected to a real account. No account or data can be deleted here.", 13, muted))
        content.addView(box)
        gap(14)
        content.addView(primaryButton("REQUEST ACCOUNT DELETION") { infoDialog("Not connected", "No deletion request was sent. Connect authentication and the account deletion endpoint before enabling this action.") })
    }

    private fun leaderboardDetailScreen() {
        content.addView(text("HOW THE BOARD WORKS", 10, seafoam, true))
        gap(6)
        content.addView(text("Leaderboard details", 25, cream, true))
        gap(12)
        infoBlock("Cycle length", "Leaderboard cycles last two weeks.")
        infoBlock("Score", "Scoring combines baseline CLAW, boosted CLAW, and Driftbox card weight for the user and eligible invitees, according to the locked mechanics.")
        infoBlock("Eligibility", "Personal activity is required. Inactive inviters do not appear.")
        infoBlock("Payout threshold", "The minimum payout threshold is $75 USDT. Admin review is required before sending payouts.")
        infoBlock("Unresolved rules", "Prize carryover below $75 and tie-breaking are not finalized. This UI does not invent those policies.")
    }

    private fun boosterScreen(which: String) {
        val tide = which == "Tide Boost"
        content.addView(text(if (tide) "MULTIPLY YOUR HAUL" else "CATCH A SQUALL", 10, seafoam, true))
        gap(6)
        content.addView(text(which, 27, cream, true))
        content.addView(text(if (tide) "Three rewarded ads, all-or-nothing." else "Three rewarded ads, all-or-nothing.", 13, muted))
        gap(18)
        val box = card().apply { setPadding(dp(18), dp(20), dp(18), dp(20)); gravity = Gravity.CENTER }
        box.addView(text(if (tide) "🌊" else "🌪", 55, gold))
        gapIn(box, 9)
        box.addView(text(if (tide) "2.5× SESSION BOOST" else "1 DRIFTBOX TOKEN", 17, gold, true))
        box.addView(text(if (tide) "Applies to the remainder of this farming session." else "Squall grants a token; it does not directly mint CLAW.", 12, muted).apply { gravity = Gravity.CENTER })
        gapIn(box, 17)
        val alreadyUsed = tide && tideBoostUsed
        box.addView(primaryButton(if (alreadyUsed) "ALREADY USED THIS SESSION" else "START AD SEQUENCE") {
            if (alreadyUsed) toast("Tide Boost can only be activated once per session.")
            else AlertDialog.Builder(this)
                .setTitle("Rewarded ads not connected")
                .setMessage("The app cannot verify real ad completion yet. This demo will not grant a boost or token from a simulated ad.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("UNDERSTOOD", null)
                .show()
        }, LinearLayout.LayoutParams(-1, dp(49)))
        content.addView(box)
        gap(12)
        content.addView(text("Production rewards must only be granted after verified rewarded-ad callbacks and server-side validation.", 11, muted))
    }

    private fun startFarming() {
        if (farming && sessionEnd > System.currentTimeMillis()) {
            toast("Your session is already running.")
            return
        }
        sessionStart = System.currentTimeMillis()
        sessionEnd = sessionStart + 6 * 60 * 60 * 1000L
        farming = true
        tideBoostUsed = false
        saveLocalState()
        render("farm")
        toast("Your six-hour session has started.")
    }

    private fun startCountdown() {
        val remainingMs = max(0L, sessionEnd - System.currentTimeMillis())
        countdown?.cancel()
        countdown = object : CountDownTimer(remainingMs, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                countdownLabel?.text = "TIME LEFT  ${formatTime(millisUntilFinished)}"
            }
            override fun onFinish() {
                finishSession()
                if (currentRoute == "farm") render("farm")
            }
        }.start()
    }

    private fun finishSession() {
        if (farming) {
            // Base reward is recorded only when a complete six-hour session ends.
            balance += 25.0
        }
        farming = false
        sessionEnd = 0L
        saveLocalState()
    }

    private fun remaining(): String = formatTime(max(0L, sessionEnd - System.currentTimeMillis()))
    private fun formatTime(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
    }

    private fun currentRank(): String = when {
        inviteCount >= 50 -> "Colony Elder"
        inviteCount >= 30 -> "Tide Master"
        inviteCount >= 15 -> "Reef Runner"
        inviteCount >= 5 -> "Deckhand"
        else -> "Hatchling"
    }

    private fun farmRewardNote() = "A complete six-hour session has a base reward of 25 CLAW. This local UI preview is not a secure rewards ledger."

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(panel, 18)
        setPadding(dp(14), dp(14), dp(14), dp(14))
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun roundedStroke(color: Int, stroke: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke) }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            includeFontPadding = true
        }

    private fun pill(value: String, fg: Int, bg: Int): TextView = text(value, 10, fg, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(7), dp(10), dp(7))
        background = rounded(bg, 50)
    }

    private fun circleButton(value: String, color: Int, onClick: () -> Unit): TextView =
        text(value, 18, color, true).apply {
            gravity = Gravity.CENTER
            background = rounded(panel2, 50)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))
        }

    private fun primaryButton(label: String, onClick: () -> Unit): TextView =
        text(label, 13, ocean, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(gold); cornerRadius = dp(13).toFloat() }
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { onClick() }
        }

    private fun secondaryButton(label: String, onClick: () -> Unit): TextView =
        text(label, 12, gold, true).apply {
            gravity = Gravity.CENTER
            background = roundedStroke(panel, gold, 13)
            setPadding(dp(12), dp(14), dp(12), dp(14))
            setOnClickListener { onClick() }
        }

    private fun input(hintText: String, password: Boolean): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(muted)
        setTextColor(cream)
        textSize = 14f
        singleLine = true
        if (password) inputType = 129
        setPadding(dp(13), 0, dp(13), 0)
        background = rounded(panel2, 12)
    }

    private fun avatar(letter: String, color: Int, size: Int): TextView = text(letter, 17, ocean, true).apply {
        gravity = Gravity.CENTER
        background = rounded(color, 50)
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }

    private fun statCard(icon: String, value: String, label: String, accent: Int): LinearLayout {
        val box = card().apply { setPadding(dp(12), dp(11), dp(12), dp(10)) }
        box.addView(text(icon, 19, accent))
        box.addView(text(value, 14, cream, true))
        box.addView(text(label, 10, muted))
        return box
    }

    private fun actionRow(icon: String, title: String, subtitle: String, action: String, accent: Int, onClick: () -> Unit) {
        val row = card().apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            isClickable = true
            setOnClickListener { onClick() }
        }
        row.addView(avatar(icon, panel2, 42).apply { setTextColor(accent); textSize = 20f })
        row.addView(space(11))
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(text(title, 13, cream, true))
        labels.addView(text(subtitle, 10, muted))
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(action, 10, accent, true))
        content.addView(row)
    }

    private fun disabledAction(icon: String, label: String): LinearLayout {
        val box = card().apply { gravity = Gravity.CENTER; alpha = 0.65f }
        box.addView(text(icon, 22, muted))
        box.addView(text(label, 12, muted, true))
        box.addView(text("At launch", 9, muted))
        return box
    }

    private fun podiumCard(emoji: String, name: String, score: String, height: Int): LinearLayout {
        val box = card().apply { gravity = Gravity.CENTER; setPadding(dp(5), dp(8), dp(5), dp(8)); background = rounded(if (emoji == "👑") Color.rgb(57, 49, 34) else panel, 15) }
        box.addView(text(emoji, 24, gold))
        box.addView(text(name, 10, cream, true).apply { gravity = Gravity.CENTER })
        box.addView(text(score, 11, gold, true))
        return box
    }

    private fun noticeCard(title: String, description: String, tag: String, accent: Int) {
        val box = card().apply { setPadding(dp(15), dp(14), dp(15), dp(14)); setOnClickListener { render("notice-detail") } }
        box.addView(pill(tag.uppercase(Locale.getDefault()), accent, panel2))
        gapIn(box, 9)
        box.addView(text(title, 15, cream, true))
        gapIn(box, 4)
        box.addView(text(description, 12, muted))
        gapIn(box, 8)
        box.addView(text("READ NOTICE  →", 10, accent, true))
        content.addView(box)
    }

    private fun missionCard(title: String, desc: String, status: String, accent: Int, click: (() -> Unit)? = null) {
        val box = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(avatar("✦", accent, 40)); box.addView(space(10))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(title, 14, cream, true)); col.addView(text(desc, 11, muted))
        box.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(pill(status.uppercase(Locale.getDefault()), accent, panel2))
        click?.let { box.setOnClickListener { it() } }
        content.addView(box)
    }

    private fun infoRow(label: String, value: String, accent: Int) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(12), dp(2), dp(12)) }
        row.addView(text(label, 12, muted), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(value, 12, accent, true))
        content.addView(row)
        content.addView(View(this).apply { setBackgroundColor(Color.rgb(35, 55, 68)) }, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun infoBlock(title: String, body: String) {
        val box = card().apply { setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(text(title, 14, cream, true))
        gapIn(box, 6)
        box.addView(text(body, 12, muted))
        content.addView(box)
        gap(9)
    }

    private fun emptyState(icon: String, title: String, body: String, action: String, onClick: () -> Unit) {
        val box = card().apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(25), dp(20), dp(22)) }
        box.addView(text(icon, 36, gold))
        gapIn(box, 8)
        box.addView(text(title, 16, cream, true).apply { gravity = Gravity.CENTER })
        gapIn(box, 5)
        box.addView(text(body, 12, muted).apply { gravity = Gravity.CENTER })
        gapIn(box, 15)
        box.addView(secondaryButton(action, onClick), LinearLayout.LayoutParams(-1, -2))
        content.addView(box)
    }

    private fun section(title: String, subtitle: String) {
        content.addView(text(title, 11, gold, true))
        content.addView(text(subtitle, 11, muted))
    }

    private fun disclaimer() {
        val note = text("UI preview · Rewards, account actions, ads, and live data require backend/service integration.", 10, muted).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(9), dp(8), dp(9))
            background = rounded(Color.rgb(10, 25, 37), 10)
        }
        content.addView(note)
    }

    private fun gap(size: Int) { content.addView(View(this), LinearLayout.LayoutParams(1, dp(size))) }
    private fun gapIn(parent: LinearLayout, size: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(size))) }
    private fun space(size: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(size), 1) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun fmt(value: Double): String = String.format(Locale.US, "%,.2f", value)

    private fun copy(value: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Ol' Crusty", value))
        toast("Copied to clipboard.")
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun infoDialog(title: String, body: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("OK", null).show()
    }
}
